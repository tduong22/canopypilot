﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CanopyManage.Domain.SeedWork
{
    public interface IEntity
    {
    }
}
