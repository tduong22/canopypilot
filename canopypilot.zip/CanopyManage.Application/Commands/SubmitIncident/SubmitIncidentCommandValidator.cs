﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace CanopyManage.Application.Commands.SubmitIncident
{
    public class SubmitIncidentCommandValidator : AbstractValidator<SubmitIncidentCommand>
    {
    }
}
