﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CanopyManage.Application.Commands.SubmitAlert
{
    class SubmitAlertCommandValidator
    {
    }
}
