﻿namespace CanopyManage.Common.EventBusServiceBus
{
    public enum EntityType {
        Queue = 0,
        Topic = 1
    }
}
